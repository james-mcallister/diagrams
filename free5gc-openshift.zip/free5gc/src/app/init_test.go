package app_test

import (
	"fmt"
	"free5gc/src/app"
	"testing"
)

func TestAppInitializeWillInitialize(t *testing.T) {
	fmt.Println("Test Start")
	app.AppInitializeWillInitialize("")
}
