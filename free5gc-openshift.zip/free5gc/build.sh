#!/usr/bin/env bash

NF_LIST="amf ausf nrf nssf pcf smf udm udr n3iwf"
export CGO_ENABLED=0
export GOOS=linux
export GOARCH=amd64

for NF in ${NF_LIST}; do 
    echo "Start build ${NF}...."
    printenv
    go build -a -o bin/${NF} -x src/${NF}/${NF}.go
done

#echo "Start build UPF...."

#cd src/upf # cwd is upf
#rm -rf build
#mkdir -p build
#cd ./build
#cmake ..
#make -j$(nproc)
