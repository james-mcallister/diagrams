#!/bin/bash
set -e

/usr/local/sonar-scanner-4.0.0.1744-linux/bin/sonar-scanner -Dsonar.projectKey=amf -Dsonar.projectBaseDir=/home/nfv-user/go/src/free5gc/src -Dsonar.sources=amf -Dsonar.host.url=http://sonarqube-devops.10-40-171-67.nip.io -Dsonar.login=e9e9f6b15fe579c90e38dc04648bb9691adf0c39
