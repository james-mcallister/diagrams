docs_site: The documentation for the okd4 cluster.
    - To view, open the 'index.html' file from any browser.

offline_webpages: Some resources saved for offline viewing.
    - The okd documentation pages were saved to deomstrate the state of them
      when I used them. Since they don't pin versions for the version 4 clusters,
      I assumed that they may be updated before they can be used.
    - Other useful articles were saved that contain some information
      that may be helpful in installing a cluster.